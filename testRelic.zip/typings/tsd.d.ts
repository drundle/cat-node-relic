
/// <reference path="node-uuid/node-uuid.d.ts" />
/// <reference path="node/node.d.ts" />
